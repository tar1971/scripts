
#!/bin/sh
#

wget -O /var/volatile/tmp/spinnerselector_2.3_all.ipk "https://drive.google.com/uc?id=15hth-adAmm4JYjINWQK-QLS0gSSpZDxw&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/spinnerselector_2.3_all.ipk
wait
sleep 2;
exit 0
























