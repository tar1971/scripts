
#!/bin/sh
#

wget -O /var/volatile/tmp/wirelesslan_6.3.ipk "https://drive.google.com/uc?id=1BSbpORd0J_Nik2NMg4LXUv-CTdnGJmxU&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/wirelesslan_6.3.ipk
wait
sleep 2;
exit 0






