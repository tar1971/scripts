opkg install --force-overwrite  http://178.63.156.75/paneladdons/Pluginsoe20/bootlogos/enigma2-plugin-extensions-bootlogo-atv-stony272_04_all.ipk
wait
sleep 2;
exit 0




