
#!/bin/sh
#

wget -O /var/volatile/tmp/tmbd_8.6_all.ipk "https://drive.google.com/uc?id=15oxpwrhXeVG8OIIj73APb6OsDFo3d3HB&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/tmbd_8.6_all.ipk
wait
sleep 2;
exit 0





















