opkg install --force-overwrite  https://drive.google.com/uc?id=1NrNn8Rn-v1gxn0cmo25zSos4kOK8vwJg&export=download
wait
sleep 2;
exit 0


























