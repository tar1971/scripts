#!/bin/sh
#

wget -O /etc/enigma2/jediplaylists/movies.m3u "https://drive.google.com/uc?id=1O6wRrKuOe9-1vdNP5lrkkEorLc7hkiNl&export=download"

exit 0



