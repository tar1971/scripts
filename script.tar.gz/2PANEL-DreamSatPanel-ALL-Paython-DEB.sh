#!/bin/sh
echo "Installing Plugin dreamsat Panel-deb "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/dreamsatpanel.deb" > /tmp/dreamsatpanel.deb
sleep 1
echo "install Plugin dreamsat panel...."
cd /tmp
opkg install /tmp/dreamsatpanel.deb
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/dreamsatpanel.deb
sleep 2
killall -9 enigma2
exit








