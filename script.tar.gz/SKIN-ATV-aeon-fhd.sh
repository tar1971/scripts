opkg install --force-overwrite  https://drive.google.com/uc?id=15xNMVU5wyTiP6uOw4f-gZ0oAnb6UV-hX&export=download
wait
sleep 2;
exit 0




