#!/bin/sh
#

wget -O /etc/tuxbox/config/ncam.server "https://drive.google.com/uc?id=1nq2smPW9BoA02KMHhzjERF3TYl7CSXhh&export=download"

exit 0














