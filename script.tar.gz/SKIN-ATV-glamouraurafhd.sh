opkg install --force-overwrite  https://drive.google.com/uc?id=1g2bBUx4GDCQCXWh8A1SOK550i91-OCuQ&export=download
wait
sleep 2;
exit 0





