#!/bin/sh

######### Only These two lines to edit with new version ######
version=22.05.2021
##############################################################

TEMPATH=/tmp
PLUGINPATH=/usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer

CHECK='/tmp/check'

# remove old version
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer
rm -rf /etc/enigma2/iptvplayerarabicgroup.json
rm -rf /etc/enigma2/iptvplayerenglishgroup.json
rm -rf /etc/enigma2/iptvplayerhostsgroups.json
rm -rf /etc/enigma2/iptvplayertsiplayercgroup.json
rm -rf /etc/tsiplayer_xtream.conf
rm -rf /iptvplayer_rootfs

# check depends packges
if [ -f /etc/apt/apt.conf ] ; then
   STATUS='/var/lib/dpkg/status'
   OS='DreamOS'
elif [ -f /etc/opkg/opkg.conf ] ; then
   STATUS='/var/lib/opkg/status'
   OS='Opensource'
fi

#if grep -q 'hlsdl' $STATUS; then
    #hlsdl='installed'
#fi
if grep -q 'duktape' $STATUS; then
    duktape='installed'
fi
if grep -q 'python-sqlite3' $STATUS; then
    python-sqlite3='installed'
fi

#if [ $hlsdl = "installed" -a $duktape = "installed" -a $python-sqlite3 = "installed" ]; then
if [ $duktape = "installed" -a $python-sqlite3 = "installed" ]; then 
     echo "All Depends Are Installed"
else
     echo "=========================================================================="
     echo "Some Depends Need to Be downloaded From Feeds ...."
     if [ $OS = "DreamOS" ]; then
          apt-get update
     else
	  echo "=========================================================================="
	  echo "Opkg Update ..."
          opkg update
     fi
          if [ $OS = "DreamOS" ]; then
              echo "========================================================================"
              echo " Downloading duktape ......"
              #apt-get install hlsdl duktape f4mdump -y
              apt-get install duktape -y
          else
              echo "========================================================================"
              #echo " Downloading hlsdl ......"
              #opkg install hlsdl
              #echo "========================================================================"
              echo " Downloading duktape ......"
              opkg install duktape
              echo "========================================================================"
              echo " Downloading python-sqlite3 ......"
              opkg install python-sqlite3
              #echo "========================================================================"
          fi
fi
echo ""
# Download and install plugin
cd /tmp
set -e
echo "===> Downloading And Insallling IPTVPlayer plugin Please Wait ......"
echo 
wget "http://ipkinstall.ath.cx/ipk-install/E2IPLAYER+TSIPLAYER/E2IPLAYER_TSiplayer.tar.gz"
tar -xzf E2IPLAYER_TSiplayer.tar.gz -C /
set +e
rm -f E2IPLAYER_TSiplayer.tar.gz
echo "checking your device Arch ....."
uname -m > $CHECK
sleep 1;
if grep -qs -i 'armv7l' cat $CHECK ; then
   echo ':Your Device IS ARM processor ...'
   echo "Add Setting To /etc/enigma2/settings ..."
   init 2
   sleep 2
   sed -i '/iptvplayer/d' /etc/enigma2/settings
   sleep 2
   echo "config.plugins.iptvplayer.SciezkaCache=/etc/IPTVCache/" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeARMV7MoviePlayer=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeARMV7MoviePlayer0=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultARMV7MoviePlayer=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultARMV7MoviePlayer0=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.remember_last_position=true" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_infobanner_clockformat=24" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_skin=red" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.plarform=armv7" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.dukpath=/usr/bin/duk" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.wgetpath=wget" >> /etc/enigma2/settings
elif grep -qs -i 'mips' cat $CHECK ; then
   echo ':Your Device IS MIPS processor ...'
   echo "Add Setting To /etc/enigma2/settings ..."
   init 2
   sleep 2
   sed -i '/iptvplayer/d' /etc/enigma2/settings
   sleep 2
   echo "config.plugins.iptvplayer.SciezkaCache=/etc/IPTVCache/" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeMIPSELMoviePlayer=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeMIPSELMoviePlayer0=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultMIPSELMoviePlayer=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultMIPSELMoviePlayer0=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.remember_last_position=true" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_infobanner_clockformat=24" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_skin=red" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.plarform=mipsel" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.dukpath=/usr/bin/duk" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.wgetpath=wget" >> /etc/enigma2/settings
elif grep -qs -i 'aarch64' cat $CHECK ; then
   echo ':Your Device IS AARCH64 processor ...'
   echo "Add Setting To /etc/enigma2/settings ..."
   init 2
   sleep 2
   sed -i '/iptvplayer/d' /etc/enigma2/settings
   sleep 2
   echo "config.plugins.iptvplayer.SciezkaCache=/etc/IPTVCache/" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeARCH64MoviePlayer=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeARCH64MoviePlayer0=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultARCH64MoviePlayer=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultARCH64MoviePlayer0=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.remember_last_position=true" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_infobanner_clockformat=24" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_skin=red" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.plarform=ARCH64" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.dukpath=/usr/bin/duk" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.wgetpath=wget" >> /etc/enigma2/settings
elif grep -qs -i 'sh4' cat $CHECK ; then
   echo ':Your Device IS SH4 processor ...'
   echo "Add Setting To /etc/enigma2/settings ..."
   init 2
   sleep 2
   sed -i '/iptvplayer/d' /etc/enigma2/settings
   sleep 2
   echo "config.plugins.iptvplayer.SciezkaCache=/etc/IPTVCache/" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeSH4MoviePlayer=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.alternativeSH4MoviePlayer0=extgstplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultSH4MoviePlayer=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.defaultSH4MoviePlayer0=exteplayer" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.remember_last_position=true" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_infobanner_clockformat=24" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.extplayer_skin=red" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.plarform=sh4" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.dukpath=/usr/bin/duk" >> /etc/enigma2/settings
   echo "config.plugins.iptvplayer.wgetpath=wget" >> /etc/enigma2/settings

fi

cd ..
sync
echo "#########################################################"
echo "#          IPTVPlayer INSTALLED SUCCESSFULLY            #"
echo "#                BY LINUXSAT - support on               #"
echo "#   https://www.tunisia-sat.com/forums/threads/4029331/ #"
echo "#########################################################"
echo "#           your Device will RESTART Now                #"
echo "#########################################################"
init 4; sleep 5; init 3
exit 0
