opkg install --force-overwrite  https://drive.google.com/uc?id=162rNgccQ0qnmyWg7e2OynRhl2yg7-PPA&export=download
wait
sleep 2;
exit 0



