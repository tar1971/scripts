
#!/bin/sh
#

wget -O /var/volatile/tmp/weatherplugin-icons_1.1_all.ipk "https://drive.google.com/uc?id=15qRIZSrFsWw95130pINHgFRepZ0pTNIj&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/weatherplugin-icons_1.1_all.ipk
wait
sleep 2;
exit 0









