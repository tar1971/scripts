#!/bin/sh
echo "Installing cccaminfo "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/cccaminfo_all.ipk" > /tmp/cccaminfo_all.ipk
sleep 1
echo "install Emu cccaminfo...."
cd /tmp
opkg install /tmp/cccaminfo_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/cccaminfo_all.ipk
sleep 2
killall -9 enigma2
exit









