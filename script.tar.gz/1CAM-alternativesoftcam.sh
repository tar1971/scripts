opkg install --force-overwrite  http://178.63.156.75/paneladdons/Pluginsoe20/cam/enigma2-plugin-extensions-alternativesoftcammanager_4.0_all.ipk
wait
sleep 2;
exit




