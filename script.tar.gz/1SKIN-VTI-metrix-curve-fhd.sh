opkg install --force-overwrite  https://raw.githubusercontent.com/emilnabil/skins-vti/main/skin-metrix-curve-fhd_1.0.2_all.ipk
wait
sleep 2;
exit 0







