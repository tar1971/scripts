wget https://raw.githubusercontent.com/emil237/fontmagnifier/main/installer.sh -qO - | /bin/sh

