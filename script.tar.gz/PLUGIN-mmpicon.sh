
#!/bin/sh
#

wget -O /var/volatile/tmp/mmpicons_1.0_all.ipk "https://drive.google.com/uc?id=15ICGJ35-jV4oaJ1iqoHK1529BI2Zvki6&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/mmpicons_1.0_all.ipk
wait
sleep 2;
exit 0






