wget -O /tmp/enigma2-plugin-extensions-epgimport_1.0+git210+20190625_all.ipk http://178.63.156.75/paneladdons/Pluginsoe20/epg/enigma2-plugin-extensions-epgimport_1.0+git210+20190625_all.ipk && opkg install --force-overwrite /tmp/enigma2-plugin-extensions-epgimport_1.0+git210+20190625_all.ipk
wait
sleep 2;
exit 0











