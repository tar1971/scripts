opkg install --force-overwrite  https://drive.google.com/uc?id=171l_9t38kKxM71gIJQML1_yrA6prLadf&export=download
wait
sleep 2;
exit 0











