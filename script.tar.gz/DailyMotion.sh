wget "http://tunisia-dreambox.info/TSplugins/DailyMotion/enigma2-plugin-extensions-dailymotion_1.0_all.ipk"
wait
sleep 2;
exit 0






