
#!/bin/sh
#

wget -O /var/volatile/tmp/quadpip_6.3.ipk "https://raw.githubusercontent.com/emilnabil/emil_script_package/main/quadpip_6.3.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/quadpip_6.3.ipk
wait
sleep 2;
exit 0









































