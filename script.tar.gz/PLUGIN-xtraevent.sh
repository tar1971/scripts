
#!/bin/sh
#

wget -O /var/volatile/tmp/xtraevent_all.ipk "https://drive.google.com/uc?id=14w0I0SphCxhQLP4AlVE0bliok_s5Lxn7&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/xtraevent_all.ipk
wait
sleep 2;
exit 0












