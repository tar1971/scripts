#!/bin/sh
#

wget -O /var/volatile/tmp/cccaminfo_01_all.ipk "https://drive.google.com/uc?id=14Zyr66vCZs7VQWy2-Eehw8K-8qkZwtlw&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/cccaminfo_01_all.ipk
wait
sleep 2;
exit
