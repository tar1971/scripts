#!/bin/sh
#

wget -O /var/volatile/tmp/ncam-supcam_all.ipk "https://raw.githubusercontent.com/emil237/plugins/main/ncam-supcam_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/ncam-supcam_all.ipk
sleep 2;
exit 0
















