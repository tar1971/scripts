
#!/bin/sh
#

wget -O /var/volatile/tmp/goldenfeed_6.8_all.ipk "https://drive.google.com/uc?id=1ihEkbt2F9YmrsMzikOKZoqQjDalfDkhq&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/goldenfeed_6.8_all.ipk
wait
sleep 2;
exit 0

























