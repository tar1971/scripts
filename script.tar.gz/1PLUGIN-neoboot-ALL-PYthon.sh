opkg update
opkg install curl
curl -kLs https://raw.githubusercontent.com/gutosie/neoboot/master/iNB.sh|sh




