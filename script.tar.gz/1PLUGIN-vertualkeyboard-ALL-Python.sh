wget http://tunisia-dreambox.info/TSplugins/NewVirtualKeyBoard/installer.sh -O - | /bin/sh

