wget https://raw.githubusercontent.com/emilnabil/cccam/main/installer.sh -O - | /bin/sh





