
#!/bin/sh
#

wget -O /var/volatile/tmp/cfg_Zoom_new_YearFIX8_all.ipk "https://drive.google.com/uc?id=142KHtEef_RxKGQLuD4SrJxu4xds8cQqM&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/cfg_Zoom_new_YearFIX8_all.ipk
wait
sleep 2;
exit 0







