opkg install --force-overwrite  https://drive.google.com/uc?id=1duaUtC5dzzmOpEkwad8yhY3GTRZxRWhy&export=download
wait
sleep 2;
exit 0

























