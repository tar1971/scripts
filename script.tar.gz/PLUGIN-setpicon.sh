
#!/bin/sh
#

wget -O /var/volatile/tmp/setpicon_01_all.ipk "https://drive.google.com/uc?id=1N2mbyK1orIKfy4HZmgc_dUWEwoLQ0qGm&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/setpicon_01_all.ipk
wait
sleep 2;
exit 0

