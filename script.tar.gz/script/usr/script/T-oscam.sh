opkg remove --force-depends enigma2-softcams-oscam-all-images
wait
sleep 2;
opkg install --force-overwrite https://drive.google.com/uc?id=1PCu03U7ZiaH5RxD2BkdGekyn8-6sAvt5&export=download
wait
sleep 2;
exit 0







