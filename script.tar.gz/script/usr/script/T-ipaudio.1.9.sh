opkg remove enigma2-plugin-extensions-ipaudio wait
sleep 2;

wget -q "--no-check-certificate" http://linuxsat5.webhop.info/ipaudio/installer.sh -O - | /bin/sh
