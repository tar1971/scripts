#!/bin/bash
# -*- coding: utf-8 -*-
#@mino60 & RAED 2021
#DESCRIPTION= This script will convert (m3u file to Bouquet list) هذا السكريبت سوف يقوم بتحويل ملف

python <<'EOF'

from zipfile import ZipFile
import os, os.path
import glob
import requests, re

LINE="************************************************************"

S = requests.Session()

NAMEBUQM3U='beIN'
NAMEm3uFile='/tmp/beIN.m3u'
E2SETTINGSPATH='/etc/enigma2'
BOUQUETSPATH='/etc/enigma2/bouquets.tv'
LastScanned='userbouquet.LastScanned.tv'
URLDOWNLOADM3U="https://drive.google.com/uc?id=1WzUsUn03ejV7NO5h_QEaymc6doow7ka5&export=download"

def remove_line(filename, what):
	if os.path.isfile(filename):
		file_read = open(filename).readlines()
		file_write = open(filename, 'w')
		for line in file_read:
			if what not in line:
				file_write.write(line)
		file_write.close()

def main():
	print(LINE)
	print("Download m3u file")
	print(LINE)
	os.system("wget --no-check-certificate -q -O /tmp/beIN.m3u %s > /dev/null 2>&1" % URLDOWNLOADM3U)
	os.system("sleep 3")
	os.system("rm -f %s/*%s* > /dev/null 2>&1" % (E2SETTINGSPATH, NAMEBUQM3U))
	os.system("sed -i '/%s/d' %s" % (NAMEBUQM3U, BOUQUETSPATH))
	BFNAME = 'userbouquet.%s.tv' % NAMEBUQM3U
	with open('%s/%s' % (E2SETTINGSPATH, BFNAME), 'w') as outfile:
		desk_tmp = ''
		outfile.write('#NAME %s\r\n' % NAMEBUQM3U)
		if os.path.isfile(NAMEm3uFile):
			for line in open(NAMEm3uFile):
				if line.startswith('http://'):
					outfile.write('#SERVICE 4097:0:1:0:0:0:0:0:0:0:%s' % line.replace(':', '%3a'))
					outfile.write('#DESCRIPTION %s' % desk_tmp)
				elif line.startswith('#EXTINF'):
					regx='''#EXTINF:-1 tvg-id="" tvg-name="(.*?)" tvg-logo=".*?" group-title=".*?"'''
					desk_tmp = '%s' % "".join(line.rsplit(",")[-1])
					#desk_tmp = '%s' % line.split('#EXTINF:-1,')[-1]
				elif '<stream_url><![CDATA' in line:
					outfile.write('#SERVICE 4097:0:1:0:0:0:0:0:0:0:%s\r\n' % line.split('[')[-1].split(']')[0].replace(':', '%3a'))
					outfile.write('#DESCRIPTION %s\r\n' % desk_tmp)
				elif '<title>' in line:
                    			if '<![CDATA[' in line:
                        			desk_tmp = '%s\r\n' % line.split('[')[-1].split(']')[0]
                    			else:
                        			desk_tmp = '%s\r\n' % line.split('<')[1].split('>')[1]
			outfile.write('\r\n')           
			outfile.close()
			if os.path.isfile(BOUQUETSPATH):
           			for line in open(BOUQUETSPATH):
            				if BFNAME in line:
                  				if os.path.isfile('%s/%s' % (E2SETTINGSPATH, BFNAME)) and os.path.isfile(BOUQUETSPATH):
                      					remove_line(BOUQUETSPATH, BFNAME)
           			with open(BOUQUETSPATH, 'a') as outfile:
            				outfile.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % BFNAME)
            				outfile.close()
            				if LastScanned in line:
                  				remove_line(BOUQUETSPATH, LastScanned)
                  				with open(BOUQUETSPATH, 'a') as outfile:
                      					outfile.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % LastScanned)
                      					outfile.close()
			os.system('wget -q -O - http://root%s@127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1  && sleep 2')
			print("Finished Downloading and Converting files")
			print(LINE)
			print(LINE)
			print("*       You will find (beIN) Folder in bouquets list       *")
			print(LINE)
			print(LINE)
			return
		else:
			print("Error in final_job")

if __name__=='__main__':
	main()
EOF
exit 0
