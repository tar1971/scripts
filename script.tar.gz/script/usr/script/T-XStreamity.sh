opkg remove enigma2-plugin-extensions-XStreamity owait
sleep 2;
opkg install --force-overwrite  https://drive.google.com/uc?id=1SneFuUYqwFUgYrx6wSOgjoh-nl5fn_fy&export=download
wait
sleep 2;
exit 0


