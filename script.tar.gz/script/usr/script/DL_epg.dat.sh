rm -r /media/hdd/epg.dat /media/usp/epg.dat
echo ""
exit 0
