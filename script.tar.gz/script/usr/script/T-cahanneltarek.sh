
#!/bin/sh
#

wget -O /var/volatile/tmp/cahannel_1.1.ipk "https://drive.google.com/uc?id=11ztG7RLVqe9ludgNd7PlLn_FfETRy6py&export=download"

wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/cahannel_1.1

sleep 2;








