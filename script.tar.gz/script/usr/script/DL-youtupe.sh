#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu Youtube"
opkg remove enigma2-plugin-extensions-youtube
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
