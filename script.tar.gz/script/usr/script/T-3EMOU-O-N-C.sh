opkg install --force-overwrite  https://drive.google.com/uc?id=1LLxCnwsKahZYiMJqP51rKE0HeX0XfSEm&export=download
wait

opkg install --force-overwrite  https://drive.google.com/uc?id=18ZMNpO53rM_-aGjwjDxEr9RhtqgJNN4W&export=download
wait

opkg install --force-overwrite  https://drive.google.com/uc?id=1Jufoj7S6Z2L_3cS8XjVNEu0-vdGZIgM8&export=download
wait
sleep 2;
exit 0

