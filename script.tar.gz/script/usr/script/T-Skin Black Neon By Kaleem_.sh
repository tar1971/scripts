opkg install --force-overwrite  https://drive.google.com/uc?id=14UP0eTwSyrV5HubaR5_z02B0Xf5E0sLH&export=download
wait
sleep 2;
exit 0










