#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu XC Player"
opkg remove xc - player
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/XCplugin/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
