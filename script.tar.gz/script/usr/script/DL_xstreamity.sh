#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu X-streamity"
opkg remove enigma2-plugin-extensions-xstreamity
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/XStreamity/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit
