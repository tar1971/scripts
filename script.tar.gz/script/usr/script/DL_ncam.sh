opkg remove enigma2-plugin-softcams-ncam-mips
wait
sleep 2;
exit 0

























