
#!/bin/sh
#

wget -O /tmp/tarek-skin-chanel.tar.gz "https://drive.google.com/uc?id=1QuQKgcrdxN-sKT3mXGJB4GhBU1ft9QlX&export=download"

tar -xzf /tmp/*.tar.gz -C /

reboot
sleep 2;

exit 0








