
#!/bin/sh
#

wget -O /var/volatile/tmp/oscam-revcam_01_all.ipk "https://drive.google.com/uc?id=1-iYQlSMqNn88s3g27THxYzJ4wri9zmvD&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/oscam-revcam_01_all.ipk

sleep 2;
exit 0



