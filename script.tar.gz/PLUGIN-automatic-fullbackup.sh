
#!/bin/sh
#

wget -O /var/volatile/tmp/automatic-fullbackup_all.ipk "https://drive.google.com/uc?id=14fWPjSrw3PLRcUfHK0CxctK3ICORemKJ&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/automatic-fullbackup_all.ipk
wait
sleep 2;
exit 0




























