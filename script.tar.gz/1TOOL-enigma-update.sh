#!/bin/sh
opkg update
opkg install python-image
opkg install python-imaging
opkg install python-argparse
opkg install python-requests
opkg install python-multiprocessing
opkg install --force-depends --force-overwrite --force-downgrade curl
opkg install --force-depends --force-overwrite --force-downgrade p7zip
opkg update
opkg install wget
opkg install curl
opkg install hlsdl
opkg install f4mdump
opkg install python-pycrypto
opkg install enigma2-plugin-systemplugins-serviceapp
opkg install ffmpeg
opkg install exteplayer3
opkg install gstplayer
echo -n "Restarting E2... "
init 4
sleep 1
init 3
exit 0







