#!/bin/sh
#
wget -O /media/hdd/emil-scripts.tar.gz "https://github.com/emilnabil/emil_script_package/raw/main/emil-scripts.tar.gz"
wait
wget -O /var/volatile/tmp/emil-scripts.tar.gz "https://github.com/emilnabil/emil_script_package/raw/main/emil-scripts.tar.gz"
wait
tar xzvpf /tmp/*.tar.gz  -C /
wait
rm -r /var/volatile/tmp/emil-scripts.tar.gz
wait
sleep 2;
exit






