#!/bin/sh
echo "Install emu-revcam "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/revcamv2-dreamos.deb" > /tmp/revcamv2-dreamos.deb
sleep 1
echo "install emu-revcam...."
cd /tmp
dpkg -i /tmp/revcamv2-dreamos.deb
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/revcamv2-dreamos.deb
sleep 2
killall -9 enigma2
exit











