#!/bin/sh
#

wget -O /var/volatile/tmp/e2iplayer_01_all.ipk "https://drive.google.com/uc?id=1E1Bv0LV3E05f3rIWck2kbGd4bmAb23Z9&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/e2iplayer_01_all.ipk
wait
sleep 2;
exit 0


