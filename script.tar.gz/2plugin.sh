opkg update 
opkg remove enigma2-plugin-extensions-serviceapp exteplayer3 ffmpeg 
opkg install ffmpeg exteplayer3 enigma2-plugin-extensions-serviceapp

wait
sleep 2;
exit 0

#!/bin/sh
#

wget -O /etc/tuxbox/satellites.xml "https://drive.google.com/uc?id=1t9kkxeco-4CM80wuBIYrL3XxcaJ-qyGr&export=download"

exit 0
