
#!/bin/sh
#

wget -O /var/volatile/tmp/quadpip_6.3.ipk "https://drive.google.com/uc?id=1BSO_Ix9Q27cu6RorZzROi-wbeiHWa6H4& export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/quadpip_6.3.ipk
wait
sleep 2;
exit 0



































