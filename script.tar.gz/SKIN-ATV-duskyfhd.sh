opkg install --force-overwrite  http://178.63.156.75/paneladdons/skins/OpenATV/enigma2-plugin-skins-duskyfhd_2.1_all.ipk
wait
sleep 2;
exit 0


























