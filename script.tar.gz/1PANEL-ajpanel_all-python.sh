wget -q "--no-check-certificate" https://raw.githubusercontent.com/emilnabil/ajpanel/main/installer.sh -O - | /bin/sh
