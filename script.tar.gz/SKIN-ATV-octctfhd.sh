opkg install --force-overwrite  https://drive.google.com/uc?id=1qSIP7uwvE2N1xMMITD_nl4dMQMiGrOso&export=download
wait
sleep 2;
exit 0



