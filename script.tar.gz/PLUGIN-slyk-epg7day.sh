
#!/bin/sh
#

wget -O /var/volatile/tmp/slykepg7day_2.02_all.ipk "https://drive.google.com/uc?id=15eJwVpy40QfNLr2roKn2cJeZj6PouTAE&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/slykepg7day_2.02_all.ipk
wait
sleep 2;
exit 0


