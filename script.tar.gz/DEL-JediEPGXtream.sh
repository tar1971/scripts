opkg remove enigma2-plugin-extensions-JediEPGXtream owait
sleep 2;
exit 0

