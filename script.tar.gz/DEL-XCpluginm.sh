opkg remove enigma2-plugin-extensions-XCplugin owait
sleep 2;
exit 0

