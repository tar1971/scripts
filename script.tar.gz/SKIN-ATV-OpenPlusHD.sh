opkg install --force-overwrite  https://drive.google.com/uc?id=1aA-X_PloqvEy74kNoyXa_L8akUqW_Yhx&export=download
wait
sleep 2;
exit 0






