
#!/bin/sh
#

wget -O /var/volatile/tmp/jediepg_01_all.ipk "https://drive.google.com/uc?id=1DBm7PNDRrUCUQsgVGcx7Bvj0OvnkeGIh&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/jediepg_01_all.ipk
wait
sleep 2;
exit 0





































