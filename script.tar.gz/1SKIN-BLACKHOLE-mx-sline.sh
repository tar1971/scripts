
#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-MX-Sline-Black-I-By-Matrix10-MOD-By-RAED.ipk "https://raw.githubusercontent.com/emil237/skins-blackhole/main/Skin-MX-Sline-Black-I-By-Matrix10-MOD-By-RAED.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skin-MX-Sline-Black-I-By-Matrix10-MOD-By-RAED.ipk
wait
sleep 2;
exit 0







