
#!/bin/sh
#

wget -O /var/volatile/tmp/skins-mxgraphite_mod.fhroma_all.ipk "https://raw.githubusercontent.com/emil237/skins-blackhole/main/skins-mxgraphite_mod.fhroma_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/skins-mxgraphite_mod.fhroma_all.ipk
wait
sleep 2;
exit 0
























