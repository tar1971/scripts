#!/bin/sh
#

wget -O /var/volatile/tmp/neoboot_8.05_all.ipk "https://github.com/emilnabil/emil_script_package/raw/main/neoboot_8.05_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/neoboot_8.05_all.ipk
wait
sleep 2;
exit 0


















