#!/bin/sh
#BY Emil
echo "download"
mkdir -p /media/hdd/download
echo "Done"
wait
wget -O /media/hdd/download/ajpanel_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/ajpanel_all.ipk"
wait
wget -O /media/hdd/download/goldenfeed_6.8_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/goldenfeed_6.8_all.ipk"
wait
wget -O /media/hdd/download/levi45-addonsmanager_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/levi45-addonsmanager_all.ipk"
wait
wget -O /media/hdd/download/cccam_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/cccam_01_all.ipk"
wait
wget -O /media/hdd/download/ncam_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/ncam_01_all.ipk"
wait
wget -O /media/hdd/download/oscam_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/oscam_01_all.ipk"
wait
wget -O /media/hdd/download/levi45multicammanager_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/levi45multicammanager_all.ipk"
wait
wget -O /media/hdd/download/satvenus_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/satvenus_01_all.ipk"
wait
wget -O /media/hdd/download/tunisiaaddon_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/tunisiaaddon_01_all.ipk"
wait
wget -O /media/hdd/download/automatic-fullbackup_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/automatic-fullbackup_all.ipk"
wait
wget -O /media/hdd/download/iptosat_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/iptosat_01_all.ipk"
wait
wget -O /media/hdd/download/jediepg_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/jediepg_01_all.ipk"
wait
wget -O /media/hdd/download/jedimaker_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/jedimaker_01_all.ipk"
wait
wget -O /media/hdd/download/menusort_v1.0_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/menusort_v1.0_all.ipk"
wait
wget -O /media/hdd/download/setpasswd_01.ipk "https://github.com/elbrins/emil_script_package/raw/main/setpasswd_01.ipk"
wait
wget -O /media/hdd/download/setpicon_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/setpicon_01_all.ipk"
wait
wget -O /media/hdd/download/subssupport_1.5.6.ipk "https://github.com/elbrins/emil_script_package/raw/main/subssupport_1.5.6.ipk"
wait
wget -O /media/hdd/download/cccaminfo_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/cccaminfo_01_all.ipk"
wait
wget -O /media/hdd/download/oscam-supcam_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/oscam-supcam_01_all.ipk"
wait
wget -O /media/hdd/download/mmpicons_1.0_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/mmpicons_1.0_all.ipk"
wait
wget -O /media/hdd/download/cfg_Zoom_new_YearFIX8_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/cfg_Zoom_new_YearFIX8_all.ipk"
wait
wget -O /media/hdd/download/script-executer.tar.gz "https://github.com/elbrins/emil_script_package/raw/main/script-executer.tar.gz"
wait
wget -O /media/hdd/download/dreamsatpanel_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/dreamsatpanel_all.ipk"
wait
wget -O /media/hdd/download/xcplugin_01_all.ipk "https://github.com/elbrins/emil_script_package/raw/main/xcplugin_01_all.ipk"
wait
sleep 1
init 3
echo "Done"
