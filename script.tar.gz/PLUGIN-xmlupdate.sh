
#!/bin/sh
#

wget -O /var/volatile/tmp/xmlupdate_6.3.ipk "https://drive.google.com/uc?id=1BVRjPdoV4dPqBZGy_z5zYmudjN7g25t6&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/xmlupdate_6.3.ipk
wait
sleep 2;
exit 0






















