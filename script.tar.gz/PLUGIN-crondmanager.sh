#!/bin/sh
#

wget -O /var/volatile/tmp/crondmanager_01_all.ipk "https://drive.google.com/uc?id=13xrjzoBnVBfapU1INJqj0ogNDZQ8CVaz&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/crondmanager_01_all.ipk

sleep 2;


