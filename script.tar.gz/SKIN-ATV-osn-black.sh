opkg install --force-overwrite  https://drive.google.com/uc?id=16sC4dj99JWRkO17O5k8BLcEDcnHTxd_o&export=download
wait
sleep 2;
exit 0






