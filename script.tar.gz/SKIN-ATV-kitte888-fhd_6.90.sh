opkg install --force-overwrite  https://drive.google.com/uc?id=1RuE6mKI6bBsvNZxWoPRJNpTOySZrRRip&export=download
wait
sleep 2;
exit 0



