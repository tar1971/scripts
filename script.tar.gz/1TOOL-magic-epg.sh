#!/bin/sh
#

wget -O /media/hdd/epg.dat "https://raw.githubusercontent.com/emil237/ziko-epg/main/epg.dat"
wait
wget -O /etc/enigma2/epg.dat "https://raw.githubusercontent.com/emil237/ziko-epg/main/epg.dat"
exit 0






