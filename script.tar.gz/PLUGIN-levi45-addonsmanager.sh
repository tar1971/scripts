#!/bin/sh
#

wget -O /var/volatile/tmp/levi45-addonsmanager_all.ipk "https://drive.google.com/uc?id=15RWpSfD8B4rd8nMB1E0-b24sYWYG1ZDl&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/levi45-addonsmanager_all.ipk
wait
sleep 2;
exit 0
