#!/bin/sh
#

wget -O /var/volatile/tmp/feeds-finder_all.ipk "https://drive.google.com/uc?id=1LM8obQo7zxFb6DGBNzchmdiXsF4OtQuM&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/feeds-finder_all.ipk
wait
sleep 2;
exit 0

























