#!/bin/sh
#

wget -O /etc/enigma2/MyMetrixLiteBackup.dat "https://a.uguu.se/uoMDHLFO.dat"

exit 0
