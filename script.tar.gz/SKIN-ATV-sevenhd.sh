opkg install --force-overwrite  https://drive.google.com/uc?id=1lbg92hN3cNZYTc3fZTZb6uJigZ-GskCN&export=download
wait
sleep 2;
exit 0




