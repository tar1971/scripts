opkg remove --force-depends enigma2-plugin-extensions-subssupport
wait
sleep 2;
exit 0
