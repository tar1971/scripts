#!/bin/sh
#

wget -O /var/volatile/tmp/ncam_01_all.ipk "https://drive.google.com/uc?id=16rUEL_6HcIW89WrRvXhhJeC4TFPFMWro&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/ncam_01_all.ipk
wait
sleep 2;
exit 0
