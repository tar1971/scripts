#!/bin/sh
#

wget -O /etc/enigma2/MyMetrixLiteBackup.dat "https://a.uguu.se/qhJtLhfn.dat"

exit 0
