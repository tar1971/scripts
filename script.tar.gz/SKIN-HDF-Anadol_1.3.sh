opkg install --force-overwrite  https://drive.google.com/uc?id=1eTfcUXqGXO820K_Zy4zibkJi7eEvbzVS&export=download
wait
sleep 2;
exit 0





