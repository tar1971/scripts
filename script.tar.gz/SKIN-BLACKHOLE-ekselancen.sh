opkg install --force-overwrite  http://178.63.156.75/paneladdons/skins/BlackHole/enigma2-plugin-skin-ekselancen_20190630-r01_all.ipk
wait
sleep 2;
exit 0






