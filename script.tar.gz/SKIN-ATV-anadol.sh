opkg install --force-overwrite  http://178.63.156.75/paneladdons/skins/OpenATV/enigma2-plugin-skins-anadol_1.4_all.ipk
wait
sleep 2;
exit 0
