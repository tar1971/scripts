opkg install --force-overwrite  https://drive.google.com/uc?id=16NuJ7gG3qrfLqQF1hip2Y0dGnFVw7lDn&export=download
wait
sleep 2;
exit 0



