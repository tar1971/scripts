
#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-NuitNeonFHD-BY-digiteng_PLi6_all.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-NuitNeonFHD-BY-digiteng_PLi6_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skin-NuitNeonFHD-BY-digiteng_PLi6_all.ipk
wait
sleep 2;
exit 0






