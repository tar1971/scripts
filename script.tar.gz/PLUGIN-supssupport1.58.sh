opkg install --force-overwrite  http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-subssupport_1.5.8-r0_all.ipk
wait
sleep 2;
exit 0
