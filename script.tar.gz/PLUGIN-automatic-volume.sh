
#!/bin/sh
#

wget -O /var/volatile/tmp/automaticvolumeadjustment_v1.0_all.ipk "https://drive.google.com/uc?id=1AAL1S4o0bw2jb9to7X3KT1m5ssO1PU0I& exportp=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/automaticvolumeadjustment_v1.0_all.ipk
wait
sleep 2;
exit 0


