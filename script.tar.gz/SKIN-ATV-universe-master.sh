opkg install --force-overwrite  https://drive.google.com/uc?id=16oGgTx0VV23uWpZQ3SbAy0ColLDLAxpD&export=download
wait
sleep 2;
exit 0








