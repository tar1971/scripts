#!/bin/sh
#

wget -O /var/volatile/tmp/levimulticam_01_all.ipk "https://drive.google.com/uc?id=1EWcHsNiW0JW9gi5t34xoMm-UbgK_IhC5&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
sleep 2;
