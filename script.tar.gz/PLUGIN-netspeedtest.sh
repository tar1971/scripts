
#!/bin/sh
#

wget -O /var/volatile/tmp/netspeedtest_1.0_all.ipk "https://drive.google.com/uc?id=15_1M5ZXoJY8fjjXJ3VRh1LouOTsMe_lx&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/netspeedtest_1.0_all.ipk
wait
sleep 2;
exit 0






























