#!/bin/sh
#

wget -O /var/volatile/tmp/epgload_0.96_all.ipk "https://drive.google.com/uc?id=14cC75D-AsdnxiLG3UuvI9cXGB4husLyW&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/epgload_0.96_all.ipk
wait
sleep 2;
exit 0







