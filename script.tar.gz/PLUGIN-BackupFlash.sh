#!/bin/sh
wget http://tunisia-dreambox.info/TSplugins/backupflash/installer.sh -O - | /bin/sh

echo "#             PLEASE RESTART YOUR STB                   #"
echo "##########################################################"
sleep 3
killall -9 enigma2
exit 0
