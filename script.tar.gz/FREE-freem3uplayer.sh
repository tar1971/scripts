#!/bin/sh
#

wget -O /media/hdd/m3uPlayer/iptv/freem3u.m3u "https://drive.google.com/uc?id=1qDwW7U9zJfmkPPz_iigXgoTZeCWgXVRW&export=download"

exit 0



