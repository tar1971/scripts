opkg install --force-overwrite  http://178.63.156.75/paneladdons/skins/OpenATV/enigma2-plugin-skins-component-army-atv_1.1-r8_all.ipk
wait
sleep 2;
exit 0







