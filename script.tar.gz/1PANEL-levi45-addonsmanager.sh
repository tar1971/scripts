wget https://raw.githubusercontent.com/emil237/levi45-addonsmanager/main/installer.sh -O - | /bin/sh


