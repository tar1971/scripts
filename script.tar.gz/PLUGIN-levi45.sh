#!/bin/sh
#

wget -O /var/volatile/tmp/levi45_01_all.ipk "https://drive.google.com/uc?id=1XtC6Gy1f7h5tq-ruCMlGdFIrPuntcyrx&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
sleep 2;

