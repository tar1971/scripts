
#!/bin/sh
#

wget -O /var/volatile/tmp/spinnerselector-sport_1.1_all.ipk "https://drive.google.com/uc?id=15m7j2wsNAwWxZZsbxOMCKRVxS_81FxBo&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/spinnerselector-sport_1.1_all.ipk
wait
sleep 2;
exit 0




