
#!/bin/sh
#

wget -O /var/volatile/tmp/setpasswd_01.ipk "https://drive.google.com/uc?id=1KP2KOzXT9tdXIO6lYYJXJtWK53_QKPG7&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/setpasswd_01.ipk
wait
sleep 2;
exit 0





















