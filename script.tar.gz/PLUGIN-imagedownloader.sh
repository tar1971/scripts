
#!/bin/sh
#

wget -O /var/volatile/tmp/image-downloader_2.0_all.ipk "https://drive.google.com/uc?id=14kEaYRY9HYkCLRwWmfjoOXIA8EHJVgrp&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/image-downloader_2.0_all.ipk
wait
sleep 2;
exit 0
































