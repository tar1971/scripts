
#!/bin/sh
#

wget -O /var/volatile/tmp/xcplugin_01_all.ipk "https://drive.google.com/uc?id=1DD7_mygGUv-gR7bcea3gSU_NqVQb2vlm&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/xcplugin_01_all.ipk
wait
sleep 2;
exit 0

















