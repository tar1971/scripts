
#!/bin/sh
#

wget -O /var/volatile/tmp/livefootball_8.5_all.ipk "https://drive.google.com/uc?id=154q7sicT-1m47WZTOqxkEkv3w2yO240D&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/livefootball_8.5_all.ipk
wait
sleep 2;
exit 0

















