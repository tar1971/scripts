#!/bin/sh

rm -rf /etc/epgimport/ziko_epg/*.xml