opkg install --force-overwrite  http://178.63.156.75/paneladdons/skins/BlackHole/Skin-MX-Sline-Black-I-By-Matrix10-MOD-By-RAED.ipk
wait
sleep 2;
exit 0





