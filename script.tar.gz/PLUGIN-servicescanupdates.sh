
#!/bin/sh
#

wget -O /var/volatile/tmp/servicescanupdates_1.1_all.ipk "https://drive.google.com/uc?id=1_jxxRtOlSwZJOJU3lIIhphUTFmmPX5iN&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/servicescanupdates_1.1_all.ipk
wait
sleep 2;
exit 0



