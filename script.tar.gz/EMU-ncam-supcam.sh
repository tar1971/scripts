#!/bin/sh
#

wget -O /var/volatile/tmp/ncam-supcam-mips_V11.7_all.ipk "https://drive.google.com/uc?id=16AANTIIGwUerT3HYNqLaskcq9XhmeyjP&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/ncam-supcam-mips_V11.7_all.ipk
wait
sleep 2;
exit 0





