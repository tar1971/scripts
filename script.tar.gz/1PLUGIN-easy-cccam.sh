#!/bin/sh
#

wget -O /var/volatile/tmp/easy-cccam-0.2-r0.ipk "https://raw.githubusercontent.com/emil237/plugins/main/easy-cccam-0.2-r0.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/easy-cccam-0.2-r0.ipk
wait
sleep 2;
exit 0


