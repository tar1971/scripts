opkg install --force-overwrite  https://drive.google.com/uc?id=151jK4ZMUArqHTo03FbvcUymqDqZ0zB6w&export=download
wait
sleep 2;
exit 0


























