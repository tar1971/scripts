
#!/bin/sh
#

wget -O /var/volatile/tmp/xstreamity_01_all.ipk "https://drive.google.com/uc?id=1Df6ELCc-0-MLzL2w4uBZLbHKlYK50nIQ&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/xstreamity_01_all.ipk
wait
sleep 2;
exit 0
















