
#!/bin/sh
#

wget -O /var/volatile/tmp/automaticcleanup_all.ipk "https://drive.google.com/uc?id=1BR1FMO2FhDbOxSnLD5j5H_j5Am1v71rW&export=download"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/automaticcleanup_all.ipk
wait
sleep 2;
exit 0


















