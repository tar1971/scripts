opkg install --force-overwrhttpshttp://178.63.156.75/paneladdons/skins/OpenATV/enigma2-plugin-skin-cerxfhd-mod_v1.1_all.ipk
wait
sleep 2;
exit 0

























