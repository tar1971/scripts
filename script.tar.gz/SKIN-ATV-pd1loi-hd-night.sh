opkg install --force-overwrite  https://drive.google.com/uc?id=1vbmhyiqm7THWj2usR3w3fdvikMx8wS5W&export=download
wait
sleep 2;
exit 0




