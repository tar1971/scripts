
#!/bin/sh
#

wget -O /var/volatile/tmp/Skins-QATAR2022-NP-FHD-By-Muaath.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skins-QATAR2022-NP-FHD-By-Muaath.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skins-QATAR2022-NP-FHD-By-Muaath.ipk
wait
sleep 2;
exit 0


