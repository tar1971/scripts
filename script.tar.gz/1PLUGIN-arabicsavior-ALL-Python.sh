wget http://tunisia-dreambox.info/TSplugins/ArabicSavior/installer.sh -O - | /bin/sh

