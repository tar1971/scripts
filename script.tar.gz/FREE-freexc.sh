#!/bin/sh
#

wget -O /etc/enigma2/xc/xc_free.xml "https://drive.google.com/uc?id=1x_kJhEoOGUGv-eSbDySZuRWbm3gAuvSc&export=download"

exit 0




