
#!/bin/sh
#

wget -O /var/volatile/tmp/maxhd.tar.gz "https://raw.githubusercontent.com/emil237/skins-openatv/main/skins-maxhd.tar.gz"
wait
tar xzvpf /tmp/*.tar.gz -C /
wait
rm -f /tmp/skins-maxhd.tar.gz
sleep 2;
exit 0































