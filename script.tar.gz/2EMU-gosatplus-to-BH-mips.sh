#!/bin/sh

TEMPATH='/tmp'
PLUGINPATH='/usr/lib/enigma2/python/Plugins/Extensions/GosatPlus'

# remove old version if any
rm -r $PLUGINPATH >/dev/null 2>&1
rm -f $PRELOADPATH >/dev/null 2>&1

set -e
cd $TEMPATH
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/gosat-mipsel-bh-r2.tgz"
wait
tar -xzf gosat-mipsel-bh-r2.tgz -C /
set +e
rm -f gosat-mipsel-bh-r2.tgz
cd ..
chmod 755 /usr/bin/gosatplus
chmod 755 /usr/camscript/Ncam_GosatPlusV1.0R2
chmod 755 /usr/uninstall/RemoveGosatPlusV1.0R2.del

echo ""
cd ..
sync
echo "#########################################################"
echo "#          GosatPlus V1.0 R2 installed successfully        #"
echo "#########################################################"
echo "#           YOUR STB WILL RESTART NOW                   #"
echo "#########################################################"
init 4
sleep 2
init 3
exit 0












