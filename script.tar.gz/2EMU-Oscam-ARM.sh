#!/bin/sh
echo "Install Oscam "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/oscam_all.ipk" > /tmp/oscam_all.ipk
sleep 1
echo "install Oscam...."
cd /tmp
opkg install /tmp/oscam_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/oscam_all.ipk
sleep 2
killall -9 enigma2
exit
