#!/bin/sh
echo "Installing skin-vti "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/skin-vti/main/skin-cerxfhd_20211113_all.ipk" > /tmp/skin-cerxfhd_20211113_all.ipk
sleep 1
echo "install skins vti...."
cd /tmp
opkg install /tmp/skin-cerxfhd_20211113_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/skin-cerxfhd_20211113_all.ipk
wait
sleep 2
exit 0














